# ColorbindProject [Sam Hendrickx] (https://github.com/Cocoparrot)

In this file I made 3 algorithms to adjust the color schemes of an image so it is more visible depending on what type of colorblindness you have.

3 types of colorblindness are present in the program. 

- deuternopia 
- tritanopia
- protonapia

## Usage

When the screen loads with the image you can either pres 1, 2 or 3.
This will change the color of the image with the algorithm in the same order as above.

To change the image edit the python file where the variable is named image and renew.

Image is the variable used to alter the images where as renew is for making the image normal again.


## License
[MIT](https://choosealicense.com/licenses/mit/)