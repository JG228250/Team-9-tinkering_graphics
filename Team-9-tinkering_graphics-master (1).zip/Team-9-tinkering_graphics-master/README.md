## Tinkering graphics task, Team 9.

Contract #1 - Platformer Tile Generator - 
Tarik Sabin [Repo link](https://github.com/Tarik458/Tinkering-Graphics-Tarik)

Contract #2 - Platformer Level Generator - 

Contract #3 - Platformer Entity Generator - 

Contract #4 - Platformer Entity Reskinning - [James Gill](https://github.com/atdeJimmyG)\
**To enable better re-use of assets, a tool which reskins in-game items and monsters devised by the dungeon entity.
You will have to remove a colour and then add a new colours.
There are four types (representing qualities) represented by a set of colours.
For example: red, green, blue and yellow.
Each unit of these teams will have to be saved in a new png file.** \
Requirements:
* Open file as .JPG
* Save new file as .PNG
* Change all of one colour e.g. red, to all of the other colours e.g. green, blue and yellow

Image used created by https://www.gamedevmarket.net/member/mobile-assets-brush/ licence - GameDev Markets standard license

Contract #5 - Colour Blindness User Interface Analysis Tool - [Sam Hendrickx](https://github.com/Cocoparrot)

### Licence - MIT 
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
