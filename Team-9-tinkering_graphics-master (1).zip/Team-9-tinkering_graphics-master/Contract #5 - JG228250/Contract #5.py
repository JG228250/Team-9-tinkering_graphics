import pygame

pixel_values_RGB = []

pygame.init()
main_window = pygame.display.set_mode((800, 600))
pict = 'Black_hole_resize_md.jpg'
black_Hole = pygame.image.load(pict)  # loads the image

width = pygame.Surface.get_width(black_Hole)  # finds the width in pixels of the image
height = pygame.Surface.get_height(black_Hole)  # finds the height in pixels of the image

x = -1  # start point for the pixel counter, is incremented as the loop continues
y = -1  # start point for the pixel counter Y-values

running = True
while running:  # keeps the pygame window running
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        main_window.blit(black_Hole, (0, 0))  # displays the image in the window
        while y < height:
            y += 1  # increments the Y-value counter
            for i in range(width):  # counts every pixel value in a row of pixels
                x += 1
                pixel_values_RGB.append(main_window.get_at((x, y)))  # appends RGB values of each pixel to a list
            x = -1
        for i in range(pixel_values_RGB[0]):
            red_value = int(pixel_values_RGB[0])
            if red_value > 240:
                int(pixel_values_RGB[0]) * 0.5  # halves the red RGB value in a highly red pixel
            else:
                pass
        pygame.display.update()
pygame.quit()
